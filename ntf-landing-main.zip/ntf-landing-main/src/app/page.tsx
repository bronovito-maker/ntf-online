"use client";

import { useState } from "react";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";

import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";

const schema = z.object({
  name: z.string().min(2, "Inserisci il tuo nome"),
  email: z.string().email("Email non valida"),
  phone: z
    .string()
    .min(7, "Inserisci un numero valido")
    .max(20, "Numero troppo lungo"),
  message: z.string().min(10, "Scrivi almeno 10 caratteri"),
});

type FormData = z.infer<typeof schema>;

export default function Page() {
  const [sent, setSent] = useState(false);
  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting },
    reset,
  } = useForm<FormData>({ resolver: zodResolver(schema) });

  const onSubmit = async (data: FormData) => {
    const res = await fetch("/api/contact", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data),
    });
    if (res.ok) {
      setSent(true);
      reset();
    }
  };

  return (
    <main className="min-h-screen bg-white">
      {/* HERO */}
      <section className="mx-auto max-w-6xl px-6 pt-20 pb-12">
        <div className="grid items-center gap-10 md:grid-cols-2">
          <div>
            <span className="rounded-full border px-3 py-1 text-xs">NikiTuttofare</span>
            <h1 className="mt-4 text-4xl font-bold tracking-tight md:text-5xl">
              Riparazioni rapide <span className="text-gray-500">e prezzi chiari</span>.
            </h1>
            <p className="mt-4 text-gray-600">
              Il tecnico giusto al momento giusto: niente attese infinite, niente sorprese sul conto.
            </p>
            <div className="mt-6 flex gap-3">
              <a href="#contatti">
                <Button size="lg">Richiedi un preventivo</Button>
              </a>
              <a href="#come-funziona">
                <Button variant="outline" size="lg">Come funziona</Button>
              </a>
            </div>
          </div>

          <Card className="border-gray-200" id="contatti">
            <CardContent className="p-6">
              {!sent ? (
                <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
                  <div className="space-y-1">
                    <Label htmlFor="name">Nome</Label>
                    <Input id="name" placeholder="Mario Rossi" {...register("name")} />
                    {errors.name && <p className="text-sm text-red-600">{errors.name.message}</p>}
                  </div>

                  <div className="space-y-1">
                    <Label htmlFor="email">Email</Label>
                    <Input id="email" type="email" placeholder="mariorossi@gmail.com" {...register("email")} />
                    {errors.email && <p className="text-sm text-red-600">{errors.email.message}</p>}
                  </div>

                  <div className="space-y-1">
                    <Label htmlFor="phone">Telefono</Label>
                    <Input
                      id="phone"
                      type="tel"
                      placeholder="333 1234567"
                      {...register("phone")}
                    />
                    {errors.phone && <p className="text-sm text-red-600">{errors.phone.message}</p>}
                  </div>

                  <div className="space-y-1">
                    <Label htmlFor="message">Messaggio</Label>
                    <Textarea id="message" rows={4} placeholder="Descrivi il tuo problema…" {...register("message")} />
                    {errors.message && <p className="text-sm text-red-600">{errors.message.message}</p>}
                  </div>

                  <Button type="submit" className="w-full" disabled={isSubmitting}>
                    {isSubmitting ? "Invio…" : "Invia richiesta"}
                  </Button>
                </form>
              ) : (
                <div className="space-y-3">
                  <h3 className="text-xl font-semibold">Richiesta inviata ✅</h3>
                  <p className="text-gray-600">Ti rispondiamo a breve con tempistiche e costi.</p>
                  <Button onClick={() => setSent(false)} variant="outline">Inviane un’altra</Button>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </section>

      {/* COME FUNZIONA */}
      <section id="come-funziona" className="mx-auto max-w-6xl px-6 pb-20">
        <h2 className="mb-10 text-center text-3xl font-bold">Come funziona</h2>
        <div className="grid gap-6 md:grid-cols-3">
          <Step n={1} title="Descrivi il problema" text="Poche info e invio. Zero burocrazia." />
          <Step n={2} title="Ricevi il preventivo" text="Prezzo chiaro e fascia oraria precisa." />
          <Step n={3} title="Intervento rapido" text="Un tecnico vicino a te arriva subito." />
        </div>
      </section>

      {/* FOOTER */}
      <footer className="border-t">
        <div className="mx-auto max-w-6xl px-6 py-8 text-sm text-gray-500">
          © {new Date().getFullYear()} NikiTuttofare · Privacy · Contatti
        </div>
      </footer>
    </main>
  );
}

function Step({ n, title, text }: { n: number; title: string; text: string }) {
  return (
    <Card>
      <CardContent className="p-6">
        <div className="mb-2 inline-flex h-8 w-8 items-center justify-center rounded-full border text-sm font-medium">
          {n}
        </div>
        <h3 className="text-lg font-semibold">{title}</h3>
        <p className="mt-1 text-gray-600">{text}</p>
      </CardContent>
    </Card>
  );
}