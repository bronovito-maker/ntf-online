import { NextResponse } from "next/server";

export async function POST(req: Request) {
  try {
    const data = await req.json(); // { name, email, phone, message }

    const { name, email, phone, message } = data ?? {};

    // Validazione minima lato server
    if (
      !name ||
      !email ||
      !message ||
      typeof name !== "string" ||
      typeof email !== "string" ||
      typeof message !== "string"
    ) {
      return NextResponse.json(
        { ok: false, error: "Dati mancanti o non validi" },
        { status: 400 }
      );
    }

    // Normalizzazione semplice del telefono (opzionale)
    const phoneNorm =
      typeof phone === "string" ? phone.trim().replace(/\s+/g, " ") : "";

    // Log per debug
    console.log("CONTACT_FORM:", { name, email, phone: phoneNorm, message });

    // Inoltro a n8n / Make (opzionale)
    const webhook = process.env.NTF_WEBHOOK_URL;
    if (webhook) {
      await fetch(webhook, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name, email, phone: phoneNorm, message }),
      });
    }

    return NextResponse.json({ ok: true });
  } catch (err) {
    console.error("CONTACT_FORM_ERROR:", err);
    return NextResponse.json(
      { ok: false, error: "Errore interno" },
      { status: 500 }
    );
  }
}